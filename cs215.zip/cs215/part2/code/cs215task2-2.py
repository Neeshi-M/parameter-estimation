import math
import numpy
import matplotlib.pyplot as plt

def poissonZ(k,i):
	f=pow(k,i)/(math.exp(k)*math.factorial(i))
	return f

numpy.random.seed(0)
distribution=numpy.random.poisson(lam=4, size=100000)
for i in range(100000):
	distribution[i]=numpy.random.binomial(distribution[i],0.8)

freq=[]
p=[]
p_hat=[]
thinning_parameter=0.8

for i in range(26):
	
	p.append(poissonZ(4*thinning_parameter,i))
	freq.append(0)
	p_hat.append(0)

freq[0]=numpy.count_nonzero((0<=distribution)&(distribution<1))
freq[1]=numpy.count_nonzero((1<=distribution)&(distribution<2))
freq[2]=numpy.count_nonzero((2<=distribution)&(distribution<3))
freq[3]=numpy.count_nonzero((3<=distribution)&(distribution<4))
freq[4]=numpy.count_nonzero((4<=distribution)&(distribution<5))
freq[5]=numpy.count_nonzero((5<=distribution)&(distribution<6))
freq[6]=numpy.count_nonzero((6<=distribution)&(distribution<7))
freq[7]=numpy.count_nonzero((7<=distribution)&(distribution<8))
freq[8]=numpy.count_nonzero((8<=distribution)&(distribution<9))
freq[9]=numpy.count_nonzero((9<=distribution)&(distribution<10))
freq[10]=numpy.count_nonzero((10<=distribution)&(distribution<11))
freq[11]=numpy.count_nonzero((11<=distribution)&(distribution<12))
freq[12]=numpy.count_nonzero((12<=distribution)&(distribution<13))
freq[13]=numpy.count_nonzero((13<=distribution)&(distribution<14))
freq[14]=numpy.count_nonzero((14<=distribution)&(distribution<15))
freq[15]=numpy.count_nonzero((15<=distribution)&(distribution<16))
freq[16]=numpy.count_nonzero((16<=distribution)&(distribution<17))
freq[17]=numpy.count_nonzero((17<=distribution)&(distribution<18))
freq[18]=numpy.count_nonzero((18<=distribution)&(distribution<19))
freq[19]=numpy.count_nonzero((19<=distribution)&(distribution<20))
freq[20]=numpy.count_nonzero((20<=distribution)&(distribution<21))
freq[21]=numpy.count_nonzero((21<=distribution)&(distribution<22))
freq[22]=numpy.count_nonzero((22<=distribution)&(distribution<23))
freq[23]=numpy.count_nonzero((23<=distribution)&(distribution<24))
freq[24]=numpy.count_nonzero((24<=distribution)&(distribution<25))
freq[25]=numpy.count_nonzero((25<=distribution)&(distribution<26))

for i in range(26):
	p_hat[i]=freq[i]/100000

print(p_hat)
print(p)
x=range(26)
plt.plot(x,p_hat,label="P hat",linestyle='dashed',marker='o',markerfacecolor='red')
plt.plot(x,p,label="P",linestyle='dashed',marker='o',markerfacecolor='green')
plt.xlabel('k')
plt.ylabel('P(Z=k)')
plt.legend()
plt.savefig("poisson_thinning.png")
plt.show()	