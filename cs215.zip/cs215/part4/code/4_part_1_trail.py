import numpy as np
import matplotlib.pyplot as plt
def random_list(n):
    list = []
    for i in range(0,n//2):
        list.append(-(pow(np.random.random(),0.5)))
        list.append(pow(np.random.random(),0.5))

    return np.array(list)


counts , bins_count = np.histogram(random_list(pow(10,5)),bins=200)
plt.hist(random_list(pow(10,5)),bins=200)
plt.savefig("hist_x_part_4.png")
plt.show()
p_dist_f = counts/sum(counts)
c_dist_f = np.cumsum(p_dist_f)

plt.plot(bins_count[1:],c_dist_f)
plt.savefig("x_c_f_f_part_4.png")

plt.show()


'''no_of_iterations, bins_count = np.histogram(random_list(pow(10, 5)), bins=200)
    random_var = np.array(bins_count[1:])
    probability = np.array(no_of_iterations)
    arr = np.array(random_list(pow(10,5)))'''
'''
def y_dist(n):
    kuch_bhi = random_list(pow(10,4))
    for i in range(0,n):
        kuch_bhi = np.add(kuch_bhi,random_list(pow(10,4)))
    kuch_bhi = kuch_bhi/n


    counts, bins_count = np.histogram(kuch_bhi, bins=200)
    pdf = counts / sum(counts)
    pdf_list = np.array(pdf)
    bins_count = np.array(bins_count)
    random_var = np.array(counts)
    for i in range(0,n-1):
        counts_1, bins_count_1 = np.histogram(kuch_bhi, bins=200)
        pdf_1 = counts_1/sum(counts_1)
        pdf_list = np.add(pdf_list,np.array(pdf_1))
        random_var = np.add(random_var,np.array(counts_1))
        bins_count = np.add(bins_count,bins_count_1)

        #random_var = np.add(random_var,np.array(bins_count[1:]))

    final_pdf_y = pdf_list/n
    plt.hist(bins_count[1:],kuch_bhi)
    cdf = np.cumsum(final_pdf_y)


    return cdf,list(random_var),list(bins_count)
plt.plot(y_dist(64)[2][1:],y_dist(64)[0])
plt.plot(y_dist(32)[2][1:],y_dist(32)[0])
plt.plot(y_dist(16)[2][1:],y_dist(16)[0])
plt.plot(y_dist(8)[2][1:],y_dist(8)[0])
plt.plot(y_dist(4)[2][1:],y_dist(4)[0])
plt.plot(y_dist(1)[2][1:],y_dist(1)[0])


plt.plot(y_dist(2)[2][1:],y_dist(2)[0])
plt.show()

def y_val(n):
    counts, bins_count = np.histogram(random_list(pow(10, 4)), bins=200)
    p_dist_f = counts / sum(counts)
    c_dist_f = np.cumsum(p_dist_f)
    for i in range(0,n-1):
        counts_1, bins_count_1 = np.histogram(random_list(pow(10, 4)), bins=200)
        p_d_f = counts_1 / sum(counts_1)

        p_dist_f = np.add(p_d_f,p_dist_f)
    cdf = np.cumsum(p_dist_f/n)
    plt.hist()
    return cdf,bins_count

plt.plot(y_val(64)[1][1:],y_val(64)[0])
plt.plot(y_val(2)[1][1:],y_val(2)[0])



plt.show()

'''

