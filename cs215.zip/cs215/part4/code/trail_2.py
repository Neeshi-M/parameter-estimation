import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import random


def our_x():
    x = random.random()
    if x <= 0.5:
        r = -(np.sqrt(1 - (2 * x)))
        return r
    else:
        r = np.sqrt((2 * x) - 1)
        return r


def our_y(n):
    x = 0
    for i in range(n):
        x = x + our_x()
    return x / n


N = 10000

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(1)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="1")
plt.hist(data,bins=200)
plt.savefig("1_hist.jpeg")
plt.show()
data = np.zeros(N)
for i in range(N):
    data[i] = our_y(2)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="2")
plt.hist(data,bins=200)
plt.savefig("2_hist.jpeg")
plt.show()
data = np.zeros(N)
for i in range(N):
    data[i] = our_y(4)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="4")
plt.hist(data,bins=200)
plt.savefig("4_hist.jpeg")
plt.show()
data = np.zeros(N)
for i in range(N):
    data[i] = our_y(8)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="8")
plt.hist(data,bins=200)
plt.savefig("8_hist.jpeg")
plt.show()
data = np.zeros(N)
for i in range(N):
    data[i] = our_y(16)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="16")
plt.hist(data,bins=200)
plt.savefig("16_hist.jpeg")
plt.show()

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(32)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="32")
plt.hist(data,bins=200)
plt.savefig("32_hist.jpeg")
plt.show()
data = np.zeros(N)
for i in range(N):
    data[i] = our_y(64)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="64")
plt.hist(data,bins=200)
plt.savefig("64_hist.jpeg")
plt.show()











for i in range(N):
    data[i] = our_y(1)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(2)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(4)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(8)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(16)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)


data = np.zeros(N)
for i in range(N):
    data[i] = our_y(32)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)

data = np.zeros(N)
for i in range(N):
    data[i] = our_y(64)
count, bins_count = np.histogram(data)
pdf = count / sum(count)
cdf = np.cumsum(pdf)
plt.plot(bins_count[1:], cdf, label="CDF")
#plt.hist(data,bins=200)
plt.savefig("part_4_2_cdf.jpeg")
plt.show()

'''
for i in range(0,7):
    data = np.zeros(N)
    for i in range(N):
        data[i] = randomgeneratorofy(pow(2,i))
    count, bins_count = np.histogram(data)
    pdf = count / sum(count)
    cdf = np.cumsum(pdf)
    #plt.plot(bins_count[1:], cdf, label="CDF")
    #plt.hist(data, bins=200)
    #plt.savefig(str(pow(2,i))+'_hist.jpeg')

    plt.plot(bins_count[1:],cdf)

    plt.show()
'''


