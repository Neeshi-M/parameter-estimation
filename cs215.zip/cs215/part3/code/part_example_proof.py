import numpy as np
import random
import statistics

def mean_for_rand(n):
    random_int = []

    for i in range(0,n):
        random_int.append(random.randint(0,100))
    our_mean  = sum(random_int)/10000
    true_mean = (100-0)/2
    error_pr = ((abs(our_mean-true_mean))/true_mean)*100
    return our_mean,true_mean,random_int,error_pr
print(f"for all true mean is 50")
for i in range(0,10000,1000):
    print(f"for n = {i}")
    print(mean_for_rand(i)[0],mean_for_rand(i)[1])
    print(f"percentage error is {mean_for_rand(i)[3]}")
print("----------------------------------------------------")
def our_variance(n):
    random_int = mean_for_rand(n)[2]
    our_mean = mean_for_rand(n)[0]
    true_mean = mean_for_rand(n)[1]

    minus_mean_square = lambda x : pow((x-true_mean),2)
    sum_of_square = list(map(minus_mean_square,random_int))
    cal_variance = sum(sum_of_square)/n
    true_variance = statistics.variance(random_int)
    error_pr = ((abs(cal_variance - true_variance)) / true_variance) * 100
    return cal_variance,true_variance,error_pr

for i in range(2,1000,100):
    print(f"for n = {i}")
    print(our_variance(i)[0],our_variance(i)[1])
    print(f"percentage error is {our_variance(i)[2]}")

