                  
import random
import math
import matplotlib.pyplot as plt
import numpy
random.seed(0)

N=[5, 10, 20, 40,60,80,100,500,1000,10000] #various dataset sizes


error_list=[]  #makes a list of lists of all the errors for each N for m=100 tries
for k in N:   #loop through each value of N
	error=[]
	for m in range(100):  #for m=100 tries
		data_list=[]
		for j in range(k):
			data_list.append(random.random())  #chooses a pseudo random number from in between (0,1)
		average=sum(data_list)/k   #calculates average
		error.append(abs(average-0.5))  #absolute value of difference between calcuated average and true mean
	
	error_list.append(error)

print(error_list)	

errors=numpy.array(error_list).transpose()

print(errors)

fig=plt.boxplot(errors, vert=True, labels=N, patch_artist=True)
plt.savefig("normal_distribution.png")

plt.show()
