import numpy as np
import matplotlib.pyplot as plt

def random_walkers(n):

    x_graph = [0]
    y_graph = [0]

    x = 0
    y = 0


    for i in range(0,n):
        probability = np.random.uniform(0,1)
        #print(probability)
        if probability < 0.5:
            #x += 1
            y += -0.001

        else:
           # x += 1
            y += 0.001

        x_graph.append(x)
        y_graph.append(y)

    return (x_graph,y_graph,x,y)


final_y = []
arr = 0
for i in range(0,pow(10,3)):
    plt.plot(random_walkers(1000)[1],range(0,1001))
    #for i in range(0,len(random_walkers(1000)[0])):

    arr = arr+np.array(random_walkers(1000)[1])

    final_y.append(random_walkers(1000)[3])
arr = arr/pow(10,3)

plt.savefig("random_walkers.png")
plt.show()

#print(len(random_walkers(100)[0]))

#print(final_y)
#counts, bins = np.histogram(final_y)
#plt.hist(bins[:,-1], bins, weights=counts)
plt.hist(final_y,200)
plt.savefig("histogram_random_walkers.png")
plt.show()
plt.plot(arr,range(0,1001),label = "computed mean path")
plt.plot(np.zeros(len(arr)),range(0,1001),label = "true mean path")
plt.xlim(-0.01,0.01)
plt.savefig("mean_path.jpeg")
plt.legend()

plt.show()
variance = 0
for i in range(0,pow(10,3)):
    variance = variance+pow((np.array(random_walkers(1000)[1])-arr),2)

variance = variance/pow(10,3)
print("the variance computed over 1000 iterations of random walks is :")
print(variance)
computed_variance = 0.001
print("error between computed variance and true variance:")
print(sum(list(variance))-0.001)
print("the error between true mean and computed mean path will be")

print(arr)




