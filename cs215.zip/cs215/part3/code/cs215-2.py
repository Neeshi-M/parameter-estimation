                  
import random
import math
import matplotlib.pyplot as plt
import numpy
numpy.random.seed(0)

N=[5, 10, 20, 40,60,80,100,500,1000,10000] #various dataset sizes


error_list=[]  #makes a list of lists of all the errors for each N for m=100 tries
for k in N:   #loop through each value of N
	error=[]
	
	for m in range(100):  #for m=100 tries
		
		data_list=numpy.random.normal(loc=0.0,scale=1.0,size=k)#chooses a pseudo random number from in between (0,1)
		avg=numpy.average(data_list)   #calculates average
		error.append(abs(avg))  #absolute value of difference between calcuated average and true mean
	
	error_list.append(error)

print(error_list)	

errors=numpy.array(error_list).transpose()

print(errors)

fig=plt.boxplot(errors, vert=True, labels=N, patch_artist=True)
plt.savefig("gaussian_distribution.png")

plt.show()
