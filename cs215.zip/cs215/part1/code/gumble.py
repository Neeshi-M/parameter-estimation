import numpy as np
import  matplotlib.pyplot as plt
import random
from scipy.stats import norm
import math
randomlist = []
for i in range(0,100):
    rand = random.uniform(-10, 10)
    randomlist.append(rand)


#print(randomlist)

'''for x in randomlist:
    if x<2:
        f_x.append((1/4)*math.exp((x-2)/2))
    else:
        f_x.append((1/4)*math.exp((2-x)/2))'''
gumble = lambda x : (1/2)*(math.exp(-(math.exp(-(x-1)/2))))*(math.exp(-(x-1)/2))



new_x= np.arange(-50,50,0.01)
f_x = list(map(gumble,new_x))

#print(f_x)
plt.plot(new_x, f_x)
plt.savefig("gumble_pdf.png")
plt.show()


'''cumulative = lambda x : math.exp(-(math.exp(-(x-1)/2)))
 c_d_f = list(map(cumulative,new_x))
plt.plot(new_x,c_d_f)'''
def cumulative(x):
    list = []
    i = -50
    while i<=x:
        list.append(gumble(i)*0.01)
        i = i+0.01
    return sum(list)
c_d_f = []
for i in new_x:
    c_d_f.append(cumulative(i))
plt.plot(new_x, c_d_f)
plt.savefig("gumble_cdf.png")
plt.show()


import statistics
#standard_deviation = lambda x : (abs(x-(25*(2-math.exp(6)))))/(20*1000)
'''standard_deviation = lambda x : abs(x-0.9999251490792619/25000)
result = list(map(standard_deviation,f_x))
sum = sum(result)/25000
variance = pow(sum,2)'''
''''each_term = lambda x : pow(abs(x-cumulative(20)/25000),2)#87433/
variance = (sum(list(map(each_term,f_x))))/25000


actual_variance = statistics.variance(f_x)
print(variance)
print(actual_variance)'''
def e_x_2(x):
    list = []
    i = -50
    while i<=x:
        list.append(gumble(i)*0.01*i*i)
        i = i+0.01
    return sum(list)



def e_x(x):
    list = []
    i = -5
    while i <= x:
        list.append(gumble(i) * 0.01 * i)
        i = i + 0.01
    return sum(list)
import statistics
our_variance = (e_x_2(50))-pow((e_x(50)),2)

print(our_variance)






