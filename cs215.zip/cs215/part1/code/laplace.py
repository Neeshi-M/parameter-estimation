import numpy as np
import  matplotlib.pyplot as plt
import random

from scipy.stats import norm
import math
randomlist = []
for i in range(0,100):
    rand = random.uniform(-10, 10)
    randomlist.append(rand)


#print(randomlist)

'''for x in randomlist:
    if x<2:
        f_x.append((1/4)*math.exp((x-2)/2))
    else:
        f_x.append((1/4)*math.exp((2-x)/2))'''
laplace = lambda x : (1/4)*(math.exp(-abs(x-2)/2))



new_x= np.arange(-50,50,0.01)
f_x = list(map(laplace,new_x))

#print(f_x)
plt.plot(new_x, f_x)
plt.savefig("laplace_pdf.png")

plt.show()


'''cumulative = lambda x : (1/2)+(1/2)*np.sign(x-2)*(1-math.exp(-abs(x-2)/2))



c_d_f = list(map(cumulative,new_x))
plt.plot(new_x,c_d_f)'''
def cumulative(x):
    list = []
    i = -50
    while i<=x:
        list.append(laplace(i)*0.01)
        i = i+0.01
    return sum(list)
c_d_f = []
for i in new_x:
    c_d_f.append(cumulative(i))
plt.plot(new_x, c_d_f)







plt.savefig("laplace_cdf.png")

plt.show()




from functools import reduce
import statistics
#standard_deviation = lambda x : (abs(x-(25*(2-math.exp(6)))))/(20*1000)
'''standard_deviation = lambda x : abs(x-0.9896028044672997/20000)
result = list(map(standard_deviation,f_x))
sum = sum(result)/20000
variance = pow(sum,2)'''

'''each_term = lambda x : pow(x-mean,2)#87433/
variance = (sum(list(map(each_term,f_x))))/20000'''

'''def our_variance(given_list):
    mean = sum(f_x)/20000
    i = -10
    list = []
    while i <= 10:
        list.append(laplace(i)*laplace(i)* 0.01)
        i = i + 0.01
    return sum(list)/20000-pow((mean),2)
'''









def e_x_2(x):
    list = []
    i = -50
    while i<=x:
        list.append(laplace(i)*0.01*i*i)
        i = i+0.01
    return sum(list)



def e_x(x):
    list = []
    i = -50
    while i <= x:
        list.append(laplace(i) * 0.01 * i)
        i = i + 0.01
    return sum(list)
import statistics
our_variance = (e_x_2(50))-pow((e_x(50)),2)


print(our_variance)


